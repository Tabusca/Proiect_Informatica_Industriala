﻿using Microsoft.AspNetCore.Identity;

namespace V3.Models
{
    public class Users : IdentityUser

    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public float Credit {  get; set; }
    }
}
