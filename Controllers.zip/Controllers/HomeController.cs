using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using V3.Models;
using System.Diagnostics;

namespace V3.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class HomeController : ControllerBase
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        // Index - GET
        [HttpGet("index")]
        public IActionResult Index()
        {
            // Po?i trimite un mesaj de succes sau date specifice aplica?iei
            return Ok(new { Message = "Welcome to the home page!" });
        }

        // Privacy - GET (Only accessible to authenticated users)
        [HttpGet("privacy")]
        [Authorize]
        public IActionResult Privacy()
        {
            // Po?i ad?uga logica pentru a returna date despre politica de confiden?ialitate
            return Ok(new { Message = "This is the privacy page. You need to be logged in to access it." });
        }

        // Error - GET
        [HttpGet("error")]
        public IActionResult Error()
        {
            var requestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier;
            return Ok(new ErrorViewModel { RequestId = requestId });
        }
    }
}
