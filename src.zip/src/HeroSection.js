import React from "react";
import "./HeroSection.css";
import backgroundVideo from "./background.mp4";
import useCountdown from "./useCountdown";  // Importă hook-ul custom

const HeroSection = () => {
  const worldCupStartDate = new Date("2026-06-11T00:00:00Z");  // Data corectă de început
  const timeLeft = useCountdown(worldCupStartDate);

  return (
    <div className="hero">
      <video autoPlay muted loop className="hero-video">
        <source src={backgroundVideo} type="video/mp4" />
        Browser-ul tău nu suportă videoclipul HTML5.
      </video>
      <div className="hero-content">
        <h1>Welcome to the 2026 FIFA World Cup!</h1>
        <p className="countdown-timer">Time left until FIFA World Cup 2026: {timeLeft}</p>
        <p>
          The world's most anticipated football event is almost here, and we are
          thrilled to bring you all the excitement and actions live from the
          heart of the competition. In 2026, the World Cup will be hosted across three nations - Canada,
          Mexico, and the United States - creating a thrilling atmosphere and
          celebrating the global unity that only football can inspire.
        </p>
        <p>
          Stay up-to-date with the match schedules, and live results, and get
          ready to experience the unforgettable moments that will define this
          year's tournament. Explore teams, player profiles, and detailed information about each
          stadium. Whether you're a die-hard football fan or just tuning in for the first
          time, we have everything you need to follow your favorite teams and
          witness history in the making.
        </p>
        <p>
          Get your tickets, secure your spot at the matches, and join us in
          celebrating the beautiful game!
        </p>
        <button className="buy-tickets">Buy Tickets</button>
      </div>
    </div>
  );
};

export default HeroSection;
