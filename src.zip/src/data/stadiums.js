// src/data/stadiums.js

export const stadiums = [
    {
        id: 1,
        country: "Canada",
        city: "Toronto",
        name: "Toronto Stadium",
        capacity: 50000,
        imageUrl: `${process.env.PUBLIC_URL}/canada.jpg`,
        description: `Toronto Stadium is set to be one of the key venues for the FIFA World Cup 2026, hosting thrilling matches
    in the heart of Canada’s largest city. Known for its modern facilities and passionate sports culture, the stadium offers
    an electrifying atmosphere for both players and fans. With a seating capacity designed to accommodate tens of thousands
    of spectators, the stadium features state-of-the-art infrastructure, ensuring an optimal viewing experience.
    Its strategic location provides easy access to transportation, accommodations, and entertainment options, making it a
    prime destination for football enthusiasts worldwide. As Canada co-hosts the prestigious tournament alongside the United
    States and Mexico, Toronto Stadium will play a vital role in showcasing the excitement of world-class football while
    reflecting the city’s vibrant multicultural spirit.`
    },
    {
        id: 2,
        country: "Canada",
        city: "Vancouver",
        name: "BC Place",
        capacity: 54000,
        imageUrl: `${process.env.PUBLIC_URL}/metlife-stadium.jpg`,
        description: `BC Place in Vancouver is renowned for its iconic retractable roof and has undergone extensive renovations
    to meet the demands of a global sporting spectacle like the FIFA World Cup 2026. With a flexible seating layout,
    the venue can comfortably host over 54,000 fans, offering premium sight lines and cutting-edge digital screens that
    bring every moment of play into sharp focus. The stadium’s rain-proof design ensures matches proceed uninterrupted by
    weather, while its eco-friendly upgrades—such as energy-efficient lighting and water recycling systems—underscore
    Canada’s commitment to sustainability. Located near downtown Vancouver, BC Place will allow visitors to combine world
    class football with the city’s rich cultural and culinary offerings, making it a standout stop on the tournament tour.`
    },
    {
        id: 3,
        country: "USA",
        city:    "Arlington",
        name:    "AT&T Stadium",
        imageUrl: "/dallas.jpg",      // <-- public/dallas.jpg
        description: `AT&T Stadium in Arlington, Texas—often called “Jerry World”—is one of the most technologically advanced
    sports venues on the planet. Home to the NFL’s Dallas Cowboys, its immense center-hung HD video board and retractable
    glass doors create an immersive environment for up to 80,000 spectators (expandable to over 100,000 for special events).
    For the FIFA World Cup 2026, the stadium’s colossal field dimensions and climate-controlled interior will ensure
    perfect playing conditions regardless of the sweltering Texan heat outside. Beyond the pitch, fans can explore
    interactive club lounges, art installations, and world-class concessions. Its proximity to the Dallas–Fort Worth
    metroplex makes AT&T Stadium a natural gathering point for football supporters from across North America.`,
        capacity: 80000
    },
    {
        id: 4,
        country: "Mexico",
        city:    "Mexico City",
        name:    "Estadio Azteca",
        imageUrl: "/mexico-city.jpg", // <-- public/mexico-city.jpg
        description: `Estadio Azteca, perched high in the mountains of Mexico City, is arguably the most legendary football
    stadium in the world. Having hosted the World Cup finals in 1970 and 1986, it is the only arena to witness two of
    football’s greatest moments—Pele’s coronation in 1970 and Maradona’s “Hand of God” in 1986. For the 2026 tournament,
    the venue has been outfitted with modern amenities, expanded VIP areas, and upgraded pitch-side technology while
    retaining its storied feel. Its 87,000-seat capacity and thin mountain air combine to produce an intimidating
    atmosphere that visiting teams will never forget. Beyond the matches, Estadio Azteca sits at the heart of Mexico
    City’s artistic and culinary scene, inviting fans to soak up the rich heritage that makes this venue truly unique.`,
        capacity: 87000
    },
];
