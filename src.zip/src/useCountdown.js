import { useState, useEffect } from 'react';

const useCountdown = (targetDate) => {
  const [timeLeft, setTimeLeft] = useState("");

  useEffect(() => {
    const interval = setInterval(() => {
      const now = new Date();
      console.log("Current time:", now);
      const timeDifference = targetDate - now;
      console.log("Time difference:", timeDifference);

      if (timeDifference <= 0) {
        setTimeLeft("The FIFA World Cup 2026 has started!");
        clearInterval(interval);
        return;
      }

      const days = Math.floor(timeDifference / (1000 * 60 * 60 * 24));
      const hours = Math.floor((timeDifference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      const minutes = Math.floor((timeDifference % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((timeDifference % (1000 * 60)) / 1000);

      setTimeLeft(`${days} days ${hours} hours ${minutes} minutes ${seconds} seconds`);
    }, 1000);

    return () => clearInterval(interval); // Curăță intervalul la despărțirea componentului
  }, [targetDate]);

  return timeLeft;
};

export default useCountdown;
