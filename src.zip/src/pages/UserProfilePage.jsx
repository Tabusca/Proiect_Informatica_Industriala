import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './UserProfilePage.css';
import Sidebar from '../components/Sidebar';

export default function UserProfilePage() {
    const [user, setUser] = useState(null);

    useEffect(() => {
        axios
            .get('https://localhost:7277/api/account/profile', { withCredentials: true })
            .then((res) => setUser(res.data))
            .catch((err) => console.error('Failed to load user profile:', err));
    }, []);

    const handleLogout = () => {
        axios
            .post('https://localhost:7277/api/account/logout', {}, { withCredentials: true })
            .then(() => {
                window.location.href = '/';
            });
    };

    if (!user) {
        return <div className="profile-page-loading">Loading profile...</div>;
    }

    return (
        <div className="profile-page-container">
            <Sidebar handleLogout={handleLogout}/>
            <div className="profile-content">
                <div className="profile-box">
                    <h2>My Profile</h2>
                    <div className="profile-form">
                        <div className="form-group">
                            <label>First Name</label>
                            <input value={user.firstName} readOnly/>
                        </div>
                        <div className="form-group">
                            <label>Last Name</label>
                            <input value={user.lastName} readOnly/>
                        </div>
                        <div className="form-group">
                            <label>Email</label>
                            <input value={user.email} readOnly/>
                        </div>
                        <div className="form-group">
                            <label>Phone Number</label>
                            <input value={user.phoneNumber || ''} readOnly/>
                        </div>
                        <div className="form-group">
                            <label>Credit</label>
                            <input value={`$${user?.credit?.toFixed(2) ?? '0.00'}`} readOnly/>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    );
}
