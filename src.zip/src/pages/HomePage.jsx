// src/pages/HomePage.jsx
import React from 'react';
import HeroSection from '../HeroSection';

export default function HomePage() {
    return (
        <div>
            <HeroSection />

            <div style={{ padding: '2rem', textAlign: 'center' }}>
                <h1>Welcome to FIFA World Cup 2026</h1>
                <p>Use the navbar to navigate to the stadiums page.</p>
            </div>
        </div>
    );
}
