import React, { useState } from 'react';
import Sidebar from '../components/Sidebar';
import './UserSettings.css';
import Navbar from '../Navbar';

export default function UserSettings() {
    const [phone, setPhone] = useState('');
    const [newPass, setNewPass] = useState('');
    const [confirmPass, setConfirmPass] = useState('');
    const [credit, setCredit] = useState('');

    const submitPhone = () => {
        if (!phone) return alert('Please enter a phone number.');
        alert(`Request to change phone number to: ${phone}`);
    };

    const submitPassword = () => {
        if (newPass !== confirmPass) {
            return alert('Passwords do not match.');
        }
        alert(`Password change request submitted.`);
    };

    const submitCredit = () => {
        if (!credit || isNaN(credit)) return alert('Enter a valid credit amount.');
        alert(`Request to add $${credit} credit submitted.`);
    };

    return (
        <>
            <Navbar />
            <div className="settings-container">
                <Sidebar />

                <div className="settings-box">
                    <h2>User Settings</h2>

                    <div className="form-group">
                        <label>New Phone Number</label>
                        <input value={phone} onChange={e => setPhone(e.target.value)} />
                        <button className="settings-btn" onClick={submitPhone}>Update Phone</button>
                    </div>

                    <div className="form-group">
                        <label>New Password</label>
                        <input type="password" value={newPass} onChange={e => setNewPass(e.target.value)} />
                        <label>Confirm Password</label>
                        <input type="password" value={confirmPass} onChange={e => setConfirmPass(e.target.value)} />
                        <button className="settings-btn" onClick={submitPassword}>Change Password</button>
                    </div>

                    <div className="form-group">
                        <label>Add Credit ($)</label>
                        <input value={credit} onChange={e => setCredit(e.target.value)} />
                        <button className="settings-btn" onClick={submitCredit}>Add Credit</button>
                    </div>
                </div>
            </div>
        </>
    );
}
