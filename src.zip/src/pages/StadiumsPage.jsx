import React from 'react';
import StadiumsSection from '../components/StadiumsSection';

export default function StadiumsPage() {
    return (
        <div style={{ padding: '2rem' }}>
            <h1>Stadiums</h1>
            <StadiumsSection />
        </div>
    );
}
