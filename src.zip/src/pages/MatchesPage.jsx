import React, { useEffect, useState } from 'react';
import './MatchesPage.css';

export default function MatchesPage() {
    const [countdown, setCountdown] = useState('');

    useEffect(() => {
        const targetDate = new Date('2026-04-01T00:00:00').getTime();

        const interval = setInterval(() => {
            const now = new Date().getTime();
            const distance = targetDate - now;

            if (distance < 0) {
                clearInterval(interval);
                setCountdown('The tournament has started!');
                return;
            }

            const days = Math.floor(distance / (1000 * 60 * 60 * 24));
            const hours = Math.floor(
                (distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)
            );
            const minutes = Math.floor(
                (distance % (1000 * 60 * 60)) / (1000 * 60)
            );
            const seconds = Math.floor((distance % (1000 * 60)) / 1000);

            setCountdown(`${days}d ${hours}h ${minutes}m ${seconds}s`);
        }, 1000);

        return () => clearInterval(interval);
    }, []);

    return (
        <div className="matches-wrapper">
            <div className="matches-menu-container">
                <div className="matches-menu">
                    <span className="active">Bracket-view</span>
                    <span>Group stage</span>
                    <span>Round of 32</span>
                    <span>Round of 16</span>
                    <span>Quarter-finals</span>
                    <span>Semi-finals</span>
                    <span>Final</span>
                </div>
            </div>

            <div className="matches-content">
                <h1>Group stage draw begins in...</h1>
                <p className="countdown">{countdown}</p>
            </div>
        </div>
    );
}
