import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import Navbar from './Navbar';
import HomePage from './pages/HomePage';
import StadiumsPage from './pages/StadiumsPage';
import MatchesPage from './pages/MatchesPage';
import UserProfilePage from './pages/UserProfilePage';
import UserSettings from './pages/UserSettings';
import AboutPage from './pages/AboutPage'; //

function App() {
    return (
        <BrowserRouter>
            <Navbar />
            <Routes>
                <Route path="/" element={<HomePage />} />
                <Route path="/stadiums" element={<StadiumsPage />} />
                <Route path="/matches" element={<MatchesPage />} />
                <Route path="/profile" element={<UserProfilePage />} />
                <Route path="/settings" element={<UserSettings />} />
                <Route path="/about" element={<AboutPage />} />
                <Route path="*" element={<Navigate to="/" replace />} />

            </Routes>
        </BrowserRouter>
    );
}

export default App;
