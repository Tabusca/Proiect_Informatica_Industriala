// src/components/Sidebar.js
import React from 'react';
import { NavLink } from 'react-router-dom';
import './Sidebar.css';

export default function Sidebar({ handleLogout }) {
    return (
        <div className="sidebar">
            <NavLink to="/profile" className="sidebar-link" activeclassname="active">
                My Account
            </NavLink>

            <NavLink to="/tickets" className="sidebar-link" activeclassname="active">
                My Tickets
            </NavLink>

            <NavLink to="/settings" className="sidebar-link" activeclassname="active">
                Settings
            </NavLink>

            <button className="sidebar-link logout-btn" onClick={handleLogout}>
                Log Out
            </button>
        </div>
    );
}
