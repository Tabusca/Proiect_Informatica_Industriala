import React, { useEffect, useState } from 'react';
import './Countdown.css';

export default function Countdown({ targetDate }) {
    const calculateTimeLeft = () => {
        const difference = +new Date(targetDate) - +new Date();
        let timeLeft = {};

        if (difference > 0) {
            timeLeft = {
                days: Math.floor(difference / (1000 * 60 * 60 * 24)),
                hours: Math.floor((difference / (1000 * 60 * 60)) % 24),
                minutes: Math.floor((difference / 1000 / 60) % 60),
                seconds: Math.floor((difference / 1000) % 60),
            };
        }

        return timeLeft;
    };

    const [timeLeft, setTimeLeft] = useState(calculateTimeLeft());

    useEffect(() => {
        const timer = setTimeout(() => {
            setTimeLeft(calculateTimeLeft());
        }, 1000);
        return () => clearTimeout(timer);
    });

    const timerComponents = Object.entries(timeLeft).map(([unit, value]) => (
        <div key={unit} className="countdown-segment">
            <div className="countdown-value">{value}</div>
            <div className="countdown-label">{unit}</div>
        </div>
    ));

    return (
        <div className="countdown-container">
            <h2 className="countdown-title">Countdown to April 2026</h2>
            <div className="countdown-timer">
                {timerComponents.length ? timerComponents : <span>Time's up!</span>}
            </div>
        </div>
    );
}
