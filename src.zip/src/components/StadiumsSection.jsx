// src/components/StadiumsSection.jsx
import React from "react";
import { stadiums } from "../data/stadiums";  // corect calea
import "./StadiumsSection.css";

export default function StadiumsSection() {
    const byCountry = stadiums.reduce((acc, s) => {
        acc[s.country] = acc[s.country] || [];
        acc[s.country].push(s);
        return acc;
    }, {});

    return (
        <div id="stadiums" className="stadiums-section">
            {Object.entries(byCountry).map(([country, list]) => (
                <section key={country} className="country-block">
                    <h2>
                        {country.toUpperCase()} ({list.length} stadiums)
                    </h2>
                    <div className="stadium-cards">
                        {list.map((s) => (
                            <div key={s.id} className="stadium-card">
                                <img src={s.imageUrl} alt={s.name} />
                                <div className="stadium-info">
                                    <h3>
                                        {s.name} — {s.city}
                                    </h3>
                                    <p>{s.description}</p>
                                    <small>Capacity: {s.capacity.toLocaleString()}</small>
                                </div>
                            </div>
                        ))}
                    </div>
                </section>
            ))}
        </div>
    );
}
