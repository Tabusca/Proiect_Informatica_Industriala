// src/components/AboutSection.jsx
import React from "react";
import "./AboutSection.css";

const AboutSection = () => {
    return (
        <section className="about-section">
            <div className="about-intro">
                <h2>Welcome to the FIFA World Cup 2026</h2>
                <p>
                    For the first time in history, the FIFA World Cup will be hosted by **three countries**:
                    <strong> Canada, Mexico, and the United States</strong>. With 48 teams and an expanded format,
                    this will be the biggest football tournament the world has ever seen.
                </p>
            </div>

            <div className="about-hosts">
                <h3>🏟️ Host Countries</h3>
                <div className="host-cards">
                    <div className="host-card">
                        <h4>🇨🇦 Canada</h4>
                        <p>Toronto and Vancouver will host world-class matches in iconic venues.</p>
                    </div>
                    <div className="host-card">
                        <h4>🇲🇽 Mexico</h4>
                        <p>Mexico becomes the first nation to host the World Cup for the third time.</p>
                    </div>
                    <div className="host-card">
                        <h4>🇺🇸 USA</h4>
                        <p>Hosting the majority of matches, the U.S. brings unmatched infrastructure and fan passion.</p>
                    </div>
                </div>
            </div>

            <div className="about-features">
                <h3>🌍 What's New in 2026?</h3>
                <ul>
                    <li>✅ 48 teams competing across North America</li>
                    <li>✅ Over 100 matches played in 16 cities</li>
                    <li>✅ Millions of fans expected to attend globally</li>
                </ul>
            </div>

            <div className="about-site">
                <h3>🌐 About This Website</h3>
                <p>
                    This platform helps fans explore stadiums, matches, and ticket information — everything you
                    need to experience the World Cup, whether you attend in person or watch from home.
                </p>
            </div>

            <div className="about-resources">
                <h3>🔗 Useful Resources</h3>
                <ul>
                    <li><a href="https://www.fifa.com" target="_blank" rel="noopener noreferrer">Official FIFA Website</a></li>
                    <li><a href="/stadiums">Stadium Guide</a></li>
                    <li><a href="/matches">Match Schedule</a></li>
                </ul>
            </div>

            <div className="about-closing">
                <p><em>Unite with the world, celebrate football, and be part of history at the FIFA World Cup 2026.</em></p>
            </div>
        </section>
    );
};

export default AboutSection;
