// components/LoginForm.jsx
import React, { useState } from "react";
import { login } from "../api";
import "./LoginForm.css";
import trophy from "../assets/trophy.png"; // asigură-te că ai această imagine

const LoginForm = ({ onSuccess, onClose }) => {
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [error, setError] = useState(null);

    const handleLogin = async (e) => {
        e.preventDefault();
        setError(null);
        try {
            const resp = await login({ email, password, rememberMe: false });
            onSuccess(resp);
        } catch (err) {
            console.error("Login error:", err);
            setError("Invalid email or password.");
        }
    };

    return (
        <div className="login-form-wrapper">
            <form className="login-form" onSubmit={handleLogin}>
                <img src={trophy} alt="World Cup Trophy" className="login-trophy" />

                <div className="form-group">
                    <label htmlFor="email">Email</label>
                    <input
                        type="email"
                        id="email"
                        placeholder="your@email.com"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        required
                    />
                </div>

                <div className="form-group">
                    <label htmlFor="password">Password</label>
                    <input
                        type="password"
                        id="password"
                        placeholder="Enter your password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        required
                    />
                </div>

                {error && <p className="error">{error}</p>}

                <button type="submit" className="login-btn">Log In</button>
                <button type="button" className="close-btn" onClick={onClose}>Close</button>
            </form>
        </div>
    );
};

export default LoginForm;
