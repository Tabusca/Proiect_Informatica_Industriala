// src/api.js
const API_URL = "http://localhost:5051";

export async function login({ email, password, rememberMe }) {
    const url = `${API_URL}/api/account/login`.trim();
    const res = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ email, password, rememberMe })
    });
    if (!res.ok) {
        const err = await res.json().catch(() => ({ message: res.statusText }));
        throw new Error(err.message || "Login failed");
    }
    return res.json();
}

export async function register({ firstName, lastName, email, password, confirmPassword }) {
    const url = `${API_URL}/api/account/register`.trim();
    const res = await fetch(url , {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ firstName, lastName, email, password, confirmPassword }),
    });
    if (!res.ok) {
        const err = await res.json().catch(() => ({ message: res.statusText }));
        throw new Error(err.message || "Registration failed");
    }
    return res.json();
}

export async function logout() {
    const res = await fetch(`${API_URL}/api/account/logout`, {
        method: "POST",
        credentials: "include",
    });
    if (!res.ok) {
        throw new Error("Logout failed");
    }
    return res.json();
}
