import React from 'react';

const UserMenu = ({ isLoggedIn, openModal, handleLogout }) => {
  return (
    <div className="user-menu-dropdown">
      {!isLoggedIn ? (
        <>
          <div className="menu-item" onClick={() => openModal("logIn")}>
            Log In
          </div>
          <div className="menu-divider"></div>
          <div className="menu-item" onClick={() => openModal("signUp")}>
            Sign Up
          </div>
        </>
      ) : (
        <>
          <div className="menu-item">My Account</div>
          <div className="menu-divider"></div>
          <div className="menu-item">My Tickets</div>
          <div className="menu-divider"></div>
          <div className="menu-item">Settings</div>
          <div className="menu-divider"></div>
          <div className="menu-item logout" onClick={handleLogout}>
            Log Out
          </div>
        </>
      )}
    </div>
  );
};

export default UserMenu;