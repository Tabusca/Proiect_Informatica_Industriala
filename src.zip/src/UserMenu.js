import React from 'react';
import { Link } from 'react-router-dom';

const UserMenu = ({ isLoggedIn, openModal, handleLogout }) => {
  return (
      <div className="user-menu-dropdown">
        {!isLoggedIn ? (
            <>
              <div className="menu-item" onClick={() => openModal("login")}>
                Log In
              </div>
              <div className="menu-divider"></div>
              <div className="menu-item" onClick={() => openModal("signup")}>
                Sign Up
              </div>
            </>
        ) : (
            <>
                <Link to="/profile" className="menu-item">My Account</Link>
                <div className="menu-divider"></div>

                <Link to="/tickets" className="menu-item">My Tickets</Link>
                <div className="menu-divider"></div>

                <Link to="/settings" className="menu-item">Settings</Link>
                <div className="menu-divider"></div>

                <div className="menu-item logout" onClick={handleLogout}>Log Out</div>
            </>

        )}
      </div>
  );
};

export default UserMenu;
