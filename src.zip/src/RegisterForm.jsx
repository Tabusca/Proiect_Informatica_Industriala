// src/components/RegisterForm.jsx
import React, { useState } from "react";
import { register } from "./api";

const RegisterForm = () => {
    const [firstName,       setFirstName]       = useState("");
    const [lastName,        setLastName]        = useState("");
    const [email,           setEmail]           = useState("");
    const [password,        setPassword]        = useState("");
    const [confirmPassword, setConfirmPassword] = useState("");
    const [message,         setMessage]         = useState("");

    const handleRegister = async (e) => {
        console.log("🔔 handleRegister fired");
        e.preventDefault();
        try {
            const response = await register({
                firstName,         // must match RegisterViewModel.FirstName
                lastName,          // must match RegisterViewModel.LastName
                email,
                password,
                confirmPassword,   // must match RegisterViewModel.ConfirmPassword
            });
            setMessage(response.message);
        } catch (err) {
            // afișează mesajul de eroare venit din server (400 Bad Request)
            setMessage(err.message);
        }
    };

    return (
        <form onSubmit={handleRegister}>
            <h2>Register</h2>

            <input
                type="text"
                placeholder="First Name"
                value={firstName}
                onChange={e => setFirstName(e.target.value)}
                required
            />

            <input
                type="text"
                placeholder="Last Name"
                value={lastName}
                onChange={e => setLastName(e.target.value)}
                required
            />

            <input
                type="email"
                placeholder="Email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                required
            />

            <input
                type="password"
                placeholder="Password"
                value={password}
                onChange={e => setPassword(e.target.value)}
                required
            />

            <input
                type="password"
                placeholder="Confirm Password"
                value={confirmPassword}
                onChange={e => setConfirmPassword(e.target.value)}
                required
            />

            <button type="submit">Create Account</button>

            {message && <p style={{ color: message.includes("failed") ? "red" : "green" }}>
                {message}
            </p>}
        </form>
    );
};

export default RegisterForm;
