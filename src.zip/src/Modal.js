import React, { useState } from 'react';
import logo from "./logo-removebg-preview.png";

const Modal = ({ isSignUp, closeModal, openModal, handleLogin }) => {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    password: '',
    confirmPassword: ''
  });

  const handleChange = (e) => {
    const { id, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [id]: value
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (isSignUp && formData.password !== formData.confirmPassword) {
      alert("Passwords don't match!");
      return;
    }
    handleLogin({
      email: formData.email,
      firstName: formData.firstName
    });
  };

  return (
    <div className="modal-overlay">
      <div className="modal-content">
        <div className="modal-header">
          <img src={logo} alt="FIFA World Cup 2026" />
          <span>FIFA World Cup 2026</span>
        </div>

        {!isSignUp ? (
          <form onSubmit={handleSubmit}>
            <label htmlFor="email">E-mail: </label>
            <input 
              type="email" 
              id="email" 
              placeholder="Enter your email" 
              value={formData.email}
              onChange={handleChange}
              required 
            />

            <label htmlFor="password">Password: </label>
            <input 
              type="password" 
              id="password" 
              placeholder="Enter your password" 
              value={formData.password}
              onChange={handleChange}
              required 
            />

            <button type="submit">Log In</button>
          </form>
        ) : (
          <form onSubmit={handleSubmit}>
            <label htmlFor="firstName">First Name: </label>
            <input 
              type="text" 
              id="firstName" 
              placeholder="Enter your first name" 
              value={formData.firstName}
              onChange={handleChange}
              required 
            />

            <label htmlFor="lastName">Last Name: </label>
            <input 
              type="text" 
              id="lastName" 
              placeholder="Enter your last name" 
              value={formData.lastName}
              onChange={handleChange}
              required 
            />

            <label htmlFor="email">E-mail: </label>
            <input 
              type="email" 
              id="email" 
              placeholder="Enter your email" 
              value={formData.email}
              onChange={handleChange}
              required 
            />

            <label htmlFor="password">Password: </label>
            <input 
              type="password" 
              id="password" 
              placeholder="Enter your password" 
              value={formData.password}
              onChange={handleChange}
              required 
            />

            <label htmlFor="confirmPassword">Confirm Password: </label>
            <input 
              type="password" 
              id="confirmPassword" 
              placeholder="Confirm your password" 
              value={formData.confirmPassword}
              onChange={handleChange}
              required 
            />

            <button type="submit">Create Account</button>
          </form>
        )}

        <hr />

        {!isSignUp ? (
          <>
            <p>You don't have an account? Register below</p>
            <button className="sign-up-btn" onClick={() => openModal("signUp")}>Sign Up</button>
          </>
        ) : (
          <>
            <p>Already have an account? Log In below</p>
            <button className="sign-up-btn" onClick={() => openModal("logIn")}>Log In</button>
          </>
        )}

        <button className="close-btn" onClick={closeModal}>Close</button>
      </div>
    </div>
  );
};

export default Modal;