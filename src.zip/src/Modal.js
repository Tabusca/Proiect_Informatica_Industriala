// src/Modal.js
import React, { useState } from 'react';
import axios from 'axios';
import logo from './logo-removebg-preview.png';
import './Modal.css';

const Modal = ({ mode, closeModal, handleLogin }) => {
  const [form, setForm] = useState({
    firstName: '',
    lastName: '',
    email: '',
    password: '',
    confirmPassword: ''
  });
  const [error, setError] = useState('');

  const handleChange = e => {
    const { id, value } = e.target;
    setForm(prev => ({ ...prev, [id]: value }));
  };

  const handleSubmit = async e => {
    e.preventDefault();
    setError('');

    try {
      if (mode === 'signup') {
        if (form.password !== form.confirmPassword) {
          setError("Passwords don't match");
          return;
        }
        const res = await axios.post(
            'https://localhost:7277/api/account/signup',
            {
              firstName: form.firstName,
              lastName: form.lastName,
              email: form.email,
              password: form.password,
              confirmPassword: form.confirmPassword
            },
            { withCredentials: true }
        );
        alert(res.data.message);
      } else {
        const res = await axios.post(
            'https://localhost:7277/api/account/login',
            {
              email: form.email,
              password: form.password,
              rememberMe: false
            },
            { withCredentials: true }
        );
        handleLogin(res.data.user);            // lift user back up
        alert(res.data.message);
      }
      closeModal();
    } catch (err) {
      const msg = err.response?.data?.message || 'Unknown error';
      setError(msg);
    }
  };

  return (
      <div className="modal-overlay">
        <div className="modal-content">
          <div className="modal-header">
            <img src={logo} alt="Logo" />
            <h3>{mode === 'signup' ? 'Create Account' : 'Log In'}</h3>
          </div>

          <form onSubmit={handleSubmit}>
            {mode === 'signup' && (
                <>
                  <label htmlFor="firstName">First Name</label>
                  <input
                      id="firstName"
                      value={form.firstName}
                      onChange={handleChange}
                      required
                  />

                  <label htmlFor="lastName">Last Name</label>
                  <input
                      id="lastName"
                      value={form.lastName}
                      onChange={handleChange}
                      required
                  />
                </>
            )}

            <label htmlFor="email">Email</label>
            <input
                id="email"
                type="email"
                value={form.email}
                onChange={handleChange}
                required
            />

            <label htmlFor="password">Password</label>
            <input
                id="password"
                type="password"
                value={form.password}
                onChange={handleChange}
                required
            />

            {mode === 'signup' && (
                <>
                  <label htmlFor="confirmPassword">Confirm Password</label>
                  <input
                      id="confirmPassword"
                      type="password"
                      value={form.confirmPassword}
                      onChange={handleChange}
                      required
                  />
                </>
            )}

            {error && <p className="error">{error}</p>}

            <button type="submit">
              {mode === 'signup' ? 'Create Account' : 'Log In'}
            </button>
          </form>

          <button className="close-btn" onClick={closeModal}>
            Close
          </button>
        </div>
      </div>
  );
};

export default Modal;
