import React, { useState, useRef, useEffect } from 'react';
import { FaUserCircle } from 'react-icons/fa';
import './Navbar.css';
import Modal from './Modal';
import UserMenu from './UserMenu';
import logo from "./logo-removebg-preview.png";

const Navbar = () => {
  // State pentru gestionarea UI
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isSignUp, setIsSignUp] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userData, setUserData] = useState(null);
  
  // Referință pentru detectarea click-urilor în afara meniului
  const menuRef = useRef(null);

  // Funcții pentru gestionarea autentificării
  const handleLogin = (user) => {
    setIsLoggedIn(true);
    setUserData({
      username: user.email.split('@')[0],
      userId: Math.floor(Math.random() * 10000)
    });
    closeModal();
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setUserData(null);
    setIsMenuOpen(false);
  };

  // Funcții pentru gestionarea meniului și modalului
  const toggleMenu = (e) => {
    e.stopPropagation();
    setIsMenuOpen(!isMenuOpen);
  };

  const openModal = (type) => {
    setIsModalOpen(true);
    setIsSignUp(type === "signUp");
    setIsMenuOpen(false);
  };

  const closeModal = () => {
    setIsModalOpen(false);
  };

  // Închide meniul la click în afara lui
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (menuRef.current && !menuRef.current.contains(event.target)) {
        setIsMenuOpen(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  return (
    <div className="navbar-container">
      <nav className="navbar">
        <div className="navbar-logo">
          <img src={logo} alt="FIFA World Cup 2026" />
          <span>FIFA World Cup 2026</span>
          <span className="countries">
          CANADA | MEXICO | UNITED STATES OF AMERICA
          </span>
        </div>

        <ul className="navbar-links">
          <li><a href="#">Stadiums</a></li>
          <li><a href="#">Buy Tickets</a></li>
          <li><a href="#">Matches</a></li>
          <li><a href="#">About</a></li>

          <li className="user-section" ref={menuRef}>
            <span 
              className="user-text" 
              onClick={() => !isLoggedIn && openModal("logIn")}
            >
              {isLoggedIn ? `${userData?.username}#${userData?.userId}` : "Log In / Sign Up"}
            </span>
            
            <div className="user-icon-wrapper" onClick={toggleMenu}>
              <FaUserCircle className="user-icon" />
            </div>

            {isMenuOpen && (
              <UserMenu 
                isLoggedIn={isLoggedIn}
                openModal={openModal}
                handleLogout={handleLogout}
              />
            )}
          </li>
        </ul>
      </nav>

      {isModalOpen && (
        <Modal 
          isSignUp={isSignUp} 
          closeModal={closeModal} 
          openModal={openModal} 
          handleLogin={handleLogin}
        />
      )}
    </div>
  );
};

export default Navbar;