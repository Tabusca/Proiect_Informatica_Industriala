import React, { useState, useRef, useEffect } from 'react';
import { NavLink } from 'react-router-dom';
import { FaUserCircle } from 'react-icons/fa';
import axios from 'axios';
import './Navbar.css';
import Modal from './Modal';
import UserMenu from './UserMenu';
import logo from './logo-removebg-preview.png';

export default function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [mode, setMode] = useState('login');
  const [userData, setUserData] = useState(null);
  const menuRef = useRef(null);

  useEffect(() => {
    axios
        .get('https://localhost:7277/api/account/profile', { withCredentials: true })
        .then(res => setUserData(res.data))
        .catch(() => setUserData(null));
  }, []);

  const openModal = (which) => {
    setMode(which);
    setIsModalOpen(true);
    setIsMenuOpen(false);
  };

  const closeModal = () => setIsModalOpen(false);

  const handleLogin = (user) => {
    setUserData(user);
    closeModal();
  };

  const handleLogout = () => {
    axios
        .post('https://localhost:7277/api/account/logout', {}, { withCredentials: true })
        .finally(() => {
          setUserData(null);
          setIsMenuOpen(false);
        });
  };

  const toggleMenu = (e) => {
    e.stopPropagation();
    setIsMenuOpen(open => !open);
  };

  useEffect(() => {
    const handleClickOutside = (e) => {
      if (menuRef.current && !menuRef.current.contains(e.target)) {
        setIsMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
      <>
        {isModalOpen && (
            <Modal mode={mode} closeModal={closeModal} handleLogin={handleLogin} />
        )}

        <nav className="navbar">
          <div className="navbar-logo">
            <img src={logo} alt="FIFA World Cup 2026" />
            <span>FIFA World Cup 2026</span>
            <span className="countries">CANADA | MEXICO | UNITED STATES OF AMERICA</span>
          </div>

          <ul className="navbar-links">
            <li>
              <NavLink to="/" end className={({ isActive }) => (isActive ? 'active' : '')}>
                Home
              </NavLink>
            </li>
            <li>
              <NavLink to="/stadiums" className={({ isActive }) => (isActive ? 'active' : '')}>
                Stadiums
              </NavLink>
            </li>
            <li>
              <NavLink to="/tickets" className={({ isActive }) => (isActive ? 'active' : '')}>
                Buy Tickets
              </NavLink>
            </li>
            <li>
              <NavLink to="/matches" className={({ isActive }) => (isActive ? 'active' : '')}>
                Matches
              </NavLink>
            </li>
            <li>
              <NavLink to="/about" className={({ isActive }) => (isActive ? 'active' : '')}>
                About
              </NavLink>
            </li>

            <li className="user-section" ref={menuRef}>
            <span className="user-text" onClick={() => !userData && openModal('login')}>
              {userData ? (
                  <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end' }}>
                    <span>{userData.email}</span>
                    <span style={{ fontSize: '0.8em', color: '#ccc' }}>
                    Credit: ${userData.credit?.toFixed(2) ?? '0.00'}
                  </span>
                  </div>
              ) : (
                  'Log In / Sign Up'
              )}
            </span>

              <FaUserCircle className="user-icon" onClick={toggleMenu} />

              {isMenuOpen && (
                  <UserMenu
                      isLoggedIn={!!userData}
                      openModal={openModal}
                      handleLogout={handleLogout}
                  />
              )}
            </li>
          </ul>
        </nav>
      </>
  );
}
